// navigation.js
function navigateTo(view) {
    window.location.href = view;
}
