// firebaseConfig.js
const firebaseConfig = {
  apiKey: "AIzaSyBtxw0C5zmnhRsOsy9i5pGGod_cq3bmSrM",
  authDomain: "speechbuddy-30390.firebaseapp.com",
  projectId: "speechbuddy-30390",
  storageBucket: "speechbuddy-30390.appspot.com",
  messagingSenderId: "19215908537",
  appId: "1:19215908537:web:28053ec7b48af8b2706568",
  measurementId: "G-KH5QEYCGKN",
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Connect to emulators
if (
  window.location.hostname === "localhost" ||
  window.location.hostname === "127.0.0.1"
) {
  firebase.auth().useEmulator("http://127.0.0.1:9099");
  firebase.firestore().useEmulator("127.0.0.1", 8080);
  firebase.storage().useEmulator("127.0.0.1", 9199);
  firebase.functions().useEmulator("127.0.0.1", 5001);
}
